package com.example.monitoringkebakaranhutanadmin;

public class Constants {
    public static String USER_UUID = "";
}
