package com.example.monitoringkebakaranhutanadmin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        init();
    }

    public void init() {
        String email = read("email", "").trim();
        String password = read("password", "");
        if (email.equals("") || password.trim().equals("")) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else {
            final ProgressDialog dialog = createDialog(R.string.logging_in);
            dialog.show();
            FirebaseDatabase.getInstance().getReference("Admins").orderByChild("email").equalTo(email)
                    .addListenerForSingleValueEvent(new ValueEventListener() {

                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                                String uuid = snapshot.getKey();
                                String name = "";
                                String storedPassword = "";
                                for (DataSnapshot snapshot2:snapshot.getChildren()) {
                                    if (snapshot2.getKey().equals("name")) {
                                        name = snapshot2.getValue(String.class);
                                    } else if (snapshot2.getKey().equals("password")) {
                                        storedPassword = snapshot2.getValue(String.class);
                                    }
                                }
                                dialog.dismiss();
                                if (password.equals(storedPassword)) {
                                    Constants.USER_UUID = uuid;
                                    write("email", email);
                                    write("password", password);
                                    startActivity(new Intent(MainActivity.this, HomeActivity.class));
                                    finish();
                                } else {
                                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                                    finish();
                                }
                                return;
                            }
                            startActivity(new Intent(MainActivity.this, LoginActivity.class));
                            finish();
                            dialog.dismiss();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
        }
    }
}