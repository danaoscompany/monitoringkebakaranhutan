package com.example.monitoringkebakaranhutanadmin;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.MultipartBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;

import org.json.JSONObject;

import java.io.File;
import java.util.concurrent.TimeUnit;

public class Util {

    public static void log(String message) {
        Log.e(Build.MODEL, message);
    }

    public static void show(Context ctx, String message) {
        Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show();
    }

    public static void show(Context ctx, int message) {
        Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show();
    }

    public static ProgressDialog createDialog(Context context, String str) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setCancelable(false);
        progressDialog.setMessage(str);
        return progressDialog;
    }

    public static ProgressDialog createDialog(Context context, int i) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setCancelable(false);
        progressDialog.setMessage(context.getResources().getString(i));
        return progressDialog;
    }

    public static void run(Runnable runnable) {
        new Thread(runnable).start();
    }

    public static void runLater(Runnable runnable) {
        new Handler(Looper.getMainLooper()).post(runnable);
    }

    public static OkHttpClient getOkHttpClient() {
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(30, TimeUnit.SECONDS);
        client.setWriteTimeout(30, TimeUnit.SECONDS);
        client.setConnectTimeout(30, TimeUnit.SECONDS);
        client.setRetryOnConnectionFailure(true);
        return client;
    }

    public interface Listener {

        void onResponse(String response);
    }

    public static void post(final Context ctx, final Listener listener, final String url, final String ...params) {
        run(new Runnable() {

            public void run() {
                try {
                    OkHttpClient client = getOkHttpClient();
                    MultipartBuilder builder = new MultipartBuilder()
                            .type(MultipartBuilder.FORM);
                    for (int i=0; i<params.length;) {
                        if (params[i].equals("file")) {
                            String fileName = params[i+1];
                            String mimeType = params[i+2];
                            String filePath = params[i+3];
                            builder.addFormDataPart("file", fileName,
                                    RequestBody.create(MediaType.parse(mimeType), new File(filePath)));
                            i += 4;
                        } else {
                            builder.addFormDataPart(params[i], params[i+1]);
                            i += 2;
                        }
                    }
                    Request request = new Request.Builder()
                            .url(url)
                            .post(builder.build())
                            .build();
                    final String response = client.newCall(request).execute().body().string();
                    runLater(new Runnable() {

                        public void run() {
                            if (listener != null) {
                                listener.onResponse(response);
                            }
                        }
                    });
                } catch (final Exception e) {
                    e.printStackTrace();
                    runLater(new Runnable() {

                        @Override
                        public void run()
                        {
                            // TODO: Implement this method
                            show(ctx, e.getMessage());
                        }
                    });
                }
            }
        });
    }

    public static String read(Context ctx, String name, String defaultValue) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        return sp.getString(name, defaultValue);
    }

    public static void write(Context ctx, String name, String value) {
        SharedPreferences sp = ctx.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        e.putString(name, value);
        e.commit();
    }

    public static String getString(JSONObject jSONObject, String str, String str2) {
        try {
            String string = jSONObject.getString(str);
            return (string == null || string.equals("null") || string.equals("NULL")) ? str2 : string;
        } catch (Exception e) {
            e.printStackTrace();
            return str2;
        }
    }

    public static int getInt(JSONObject jSONObject, String str, int i) {
        try {
            String string = jSONObject.getString(str);
            if (string != null && !string.equals("null")) {
                if (!string.equals("NULL")) {
                    return Integer.parseInt(string);
                }
            }
            return i;
        } catch (Exception e) {
            e.printStackTrace();
            return i;
        }
    }

    public static double getDouble(JSONObject jSONObject, String str, double d) {
        try {
            String string = jSONObject.getString(str);
            if (string != null && !string.equals("null")) {
                if (!string.equals("NULL")) {
                    return Double.parseDouble(string);
                }
            }
            return d;
        } catch (Exception e) {
            e.printStackTrace();
            return d;
        }
    }

    public static void sendMessage(final String title, final String body, final String token) {
        run(new Runnable() {

            @Override
            public void run() {
                try {
                    OkHttpClient client = new OkHttpClient();
                    client.setConnectTimeout(60, TimeUnit.SECONDS);
                    client.setReadTimeout(60, TimeUnit.SECONDS);
                    client.setWriteTimeout(60, TimeUnit.SECONDS);
                    JSONObject payload = new JSONObject();
                    payload.put("to", token);
                    JSONObject notification = new JSONObject();
                    notification.put("title", title);
                    notification.put("body", body);
                    notification.put("sound", "default");
                    notification.put("badge", "1");
                    //data.put("notification", notification);
                    payload.put("priority", "high");
                    JSONObject data = new JSONObject();
                    data.put("title", title);
                    data.put("body", body);
                    payload.put("data", data);
                    RequestBody params = RequestBody.create(MediaType.parse("application/json"), payload.toString());
                    Request request = new Request.Builder()
                            .url("https://fcm.googleapis.com/fcm/send")
                            .addHeader("Content-Type", "application/json")
                            .addHeader("Authorization", "key=AAAAaO3gjtg:APA91bFmpMhFM-55NkTupT6V_9RwN75v5i6iI2jn_TT6rpHk7LgL6fuRynmjcd4adBr9RVVbfy1QhJvDAzDX9RX9eGg-G8DXXvXn41LK47Qv0shx7kQZe0za8iLkstgbVRd9TCCQmKng")
                            .post(params)
                            .build();
                    final String response = client.newCall(request).execute().body().string();
                    runLater(new Runnable() {

                        @Override
                        public void run() {
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
