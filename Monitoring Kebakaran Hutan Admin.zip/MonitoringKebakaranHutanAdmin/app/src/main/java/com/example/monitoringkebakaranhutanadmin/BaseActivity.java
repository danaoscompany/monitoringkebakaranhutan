package com.example.monitoringkebakaranhutanadmin;

import android.app.ProgressDialog;

import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {

    public void log(String message) {
        Util.log(message);
    }

    public void show(String message) {
        Util.show(this, message);
    }

    public void show(int message) {
        Util.show(this, message);
    }

    public ProgressDialog createDialog(String str) {
        return Util.createDialog(this, str);
    }

    public ProgressDialog createDialog(int i) {
        return Util.createDialog(this, i);
    }

    public String read(String name, String value) {
        return Util.read(this, name, value);
    }

    public void write(String name, String value) {
        Util.write(this, name, value);
    }

    public interface Listener {

        void onResponse(String response);
    }

    public void post(final Listener listener, final String url, final String ...params) {
        Util.post(this, new Util.Listener() {

            @Override
            public void onResponse(String response) {
                if (listener != null) {
                    listener.onResponse(response);
                }
            }
        }, url, params);
    }
}
