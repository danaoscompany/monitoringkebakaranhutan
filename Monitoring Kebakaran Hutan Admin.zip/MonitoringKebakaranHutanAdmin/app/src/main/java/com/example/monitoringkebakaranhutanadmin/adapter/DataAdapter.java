package com.example.monitoringkebakaranhutanadmin.adapter;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.monitoringkebakaranhutanadmin.R;
import com.example.monitoringkebakaranhutanadmin.Util;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    Context context;
    ArrayList<JSONObject> data;
    Listener listener;

    public DataAdapter(Context ctx, ArrayList<JSONObject> data, Listener listener) {
        this.context = ctx;
        this.data = data;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.data, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            final JSONObject datum = data.get(position);
            holder.select.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onSelected(position, datum);
                    }
                }
            });
            holder.locationView.setText(Html.fromHtml("<b>"+context.getResources().getString(R.string.location)+":</b> "
                    +Util.getString(datum, "lokasiKebakaran", "").trim()));
            try {
                holder.dateView.setText(Html.fromHtml("<b>"+context.getResources().getString(R.string.date) + ":</b> "
                        + new SimpleDateFormat("d MMMM yyyy HH:mm:ss").format(
                        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(
                                Util.getString(datum, "date", "").trim()).getTime()
                )));
            } catch (Exception e) {
                e.printStackTrace();
            }
            holder.userNameView.setText(Html.fromHtml("<b>"+context.getResources().getString(R.string.text11)+":</b> "
                    +Util.getString(datum, "user_name", "").trim()));
            holder.phoneView.setText(Html.fromHtml("<b>"+context.getResources().getString(R.string.text22)+":</b> "
                    +Util.getString(datum, "noTelp", "").trim()));
            holder.penyebabKebakaranView.setText(Html.fromHtml("<b>"+context.getResources().getString(R.string.text21)+":</b> "
                    +Util.getString(datum, "penyebabKebakaran", "").trim()));
            String status = Util.getString(datum, "status", "").trim();
            if (status.equals("terbakar")) {
                holder.statusView.setText(Html.fromHtml("<b>"+context.getResources().getString(R.string.status)+":</b> "
                            +"<b><font color='#e74c3c'>"+context.getResources().getString(R.string.text9)+"</font></b>"));
            } else if (status.equals("proses")) {
                holder.statusView.setText(Html.fromHtml("<b>"+context.getResources().getString(R.string.status)+":</b> "
                        +"<b><font color='#3498db'>"+context.getResources().getString(R.string.process)+"</font></b>"));
            } else if (status.equals("padam")) {
                holder.statusView.setText(Html.fromHtml("<b>"+context.getResources().getString(R.string.status)+":</b> "
                        +"<b><font color='#2ecc71'>"+context.getResources().getString(R.string.text10)+"</font></b>"));
            } else {
                holder.statusView.setText(Html.fromHtml("<b>"+context.getResources().getString(R.string.status)+":</b> "
                        +"<b><font color='#3498db'>"+status+"</font></b>"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public LinearLayout select;
        public TextView locationView, dateView, userNameView, phoneView, penyebabKebakaranView, statusView;

        public ViewHolder(View view) {
            super(view);
            select = view.findViewById(R.id.select);
            locationView = view.findViewById(R.id.location);
            dateView = view.findViewById(R.id.date);
            userNameView = view.findViewById(R.id.user_name);
            phoneView = view.findViewById(R.id.phone);
            statusView = view.findViewById(R.id.status);
            penyebabKebakaranView = view.findViewById(R.id.penyebab_kebakaran);
        }
    }

    public interface Listener {

        void onSelected(int position, JSONObject datum);
    }
}
