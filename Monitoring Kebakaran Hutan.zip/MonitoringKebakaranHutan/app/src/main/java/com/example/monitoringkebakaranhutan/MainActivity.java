package com.example.monitoringkebakaranhutan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView register, forgetPassword;
    private EditText editTextEmail, editTextPassword;
    private Button login;

    private FirebaseAuth mAuth;
    private ProgressBar progressBar;
    private String[] permissions = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
    };
    private TextView outputView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        outputView = findViewById(R.id.output);
        register = (TextView) findViewById( R.id.registrasi );
        register.setOnClickListener( this );

        login = (Button) findViewById( R.id.login );
        login.setOnClickListener( this );

        editTextEmail = (EditText) findViewById( R.id.email );
        editTextPassword = (EditText) findViewById( R.id.password );

        progressBar = (ProgressBar) findViewById( R.id.progressBar );

        mAuth = FirebaseAuth.getInstance();

        forgetPassword = (TextView) findViewById( R.id.forgetPassword );
        forgetPassword.setOnClickListener( this );
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(permissions[0]) != PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(permissions[1]) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(permissions, 1);
            } else {
                init();
            }
        } else {
            init();
        }
    }

    public void append(String output) {
        outputView.append(output+"\n");
        final ScrollView scroller = findViewById(R.id.scroller);
        scroller.post(new Runnable() {

            @Override
            public void run() {
                scroller.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    public void init() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager mgr = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel channel = new NotificationChannel(getPackageName() + ".NOTIFICATIONS", "Notifications for Monitoring Kebakaran Hutan", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Manage notifications for Monitoring Kebakaran Hutan");
            mgr.createNotificationChannel(channel);
        }
        String email = Tool.read(this, "email", "").trim();
        String password = Tool.read(this, "password", "");
        if (!email.equals("") && !password.trim().equals("")) {
            login(email, password);
        }
    }

    public void login(final String email, final String password) {
        append("This line 1");
        final ProgressDialog dialog = Tool.createDialog(MainActivity.this, R.string.text1);
        dialog.show();
        append("This line 2");
        mAuth.signInWithEmailAndPassword( email, password ).addOnCompleteListener( new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                append("This line 3");
                if (task.isSuccessful()){
                    append("This line 4");
                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                    append("This line 5");
                    if(user.isEmailVerified()){
                        append("This line 6");
                        Tool.write(MainActivity.this, "email", email);
                        append("This line 7");
                        Tool.write(MainActivity.this,
                                "password",
                                password);
                        append("This line 8");
                        String fcmID = FirebaseInstanceId.getInstance().getToken();
                        append("This line 9");
                        dialog.dismiss();
                        append("This line 11");
                        startActivity( new Intent( MainActivity.this, tampilanUtama.class ) );
                        append("This line 12");
                        finish();
                        append("This line 13");
                    }else{
                        append("This line 14");
                        dialog.dismiss();
                        append("This line 15");
                        user.sendEmailVerification();
                        append("This line 16");
                        Toast.makeText( MainActivity.this, "Periksa email Anda untuk memverifikasi akun Anda", Toast.LENGTH_SHORT ).show();
                        append("This line 17");
                    }


                }else {
                    append("This line 18");
                    dialog.dismiss();
                    append("This line 19");
                    Toast.makeText( MainActivity.this, "Gagal Login! Mohon periksa email dan password", Toast.LENGTH_SHORT).show();
                    append("This line 20");
                }
            }
        });
    }

    public void onClick(View view) {
        append("This line 21");
        switch (view.getId()) {
            case R.id.registrasi:
                startActivity( new Intent( this, RegisterUser.class ) );
                break;
            case R.id.login:
                append("This line 22");
                userLogin();
                append("This line 23");
                break;
            case R.id.forgetPassword:
                startActivity( new Intent( this, forgetPassword.class ) );
                break;
        }
    }

    private void userLogin() {
        append("This line 24");
        final String email = editTextEmail.getText().toString().trim();
        append("This line 25");
        final String password = editTextPassword.getText().toString().trim();
        append("This line 26");
        if (email.isEmpty()) {
            append("This line 27");
            editTextEmail.setError( "Email tidak boleh kosong!" );
            append("This line 28");
            editTextEmail.requestFocus();
            append("This line 29");
            return;
        }
        append("This line 30");
        if (!Patterns.EMAIL_ADDRESS.matcher( email ).matches()) {
            append("This line 31");
            editTextEmail.setError( "Tolong masukkan email yang benar!" );
            append("This line 32");
            editTextEmail.requestFocus();
            append("This line 33");
            return;
        }
        append("This line 34");
        if (password.isEmpty()) {
            append("This line 35");
            editTextPassword.setError( "Password tidak boleh kosong!" );
            append("This line 36");
            editTextPassword.requestFocus();
            append("This line 37");
            return;
        }
        append("This line 38");
        if (password.length() < 6){
            append("This line 39");
            editTextPassword.setError( "Kata Sandi Minimal 6 karakter!" );
            append("This line 40");
            editTextPassword.requestFocus();
            append("This line 41");
            return;
        }
        append("This line 42");
        progressBar.setVisibility( View.GONE );
        append("This line 43");
        login(email, password);
        append("This line 44");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            boolean granted = true;
            for (int result:grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    granted = false;
                    break;
                }
            }
            if (granted) {
                init();
            } else {
                finish();
            }
        }
    }
}