package com.example.monitoringkebakaranhutan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class forgetPassword extends AppCompatActivity {
    private EditText editTextEmail;
    private Button btnresetPassword;
    private ProgressBar progressBarForget;

    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_forget_password );

        editTextEmail = (EditText) findViewById( R.id.forgetEmail );
        btnresetPassword = (Button) findViewById( R.id.btnresetPassword );
        progressBarForget = (ProgressBar) findViewById( R.id.progressBarForget );

        auth = FirebaseAuth.getInstance();

        btnresetPassword.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetPassword();
            }

            private void resetPassword() {
                String email = editTextEmail.getText().toString().trim();

                if (email.isEmpty()) {
                    editTextEmail.setError( "Email diperlukan" );
                    editTextEmail.requestFocus();
                    return;
                }
                if (!Patterns.EMAIL_ADDRESS.matcher( email ).matches()) {
                    editTextEmail.setError( "Tolong masukkan email yang benar!" );
                    editTextEmail.requestFocus();
                    return;
                }
                progressBarForget.setVisibility( View.VISIBLE );
                auth.sendPasswordResetEmail( email ).addOnCompleteListener( new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Toast.makeText( forgetPassword.this, "Periksa email Anda untuk mengatur ulang kata sandi!", Toast.LENGTH_LONG ).show();
                        }else{
                            Toast.makeText( forgetPassword.this, "Coba lagi! Sesuatu yang salah terjadi!", Toast.LENGTH_LONG ).show();
                        }
                    }
                });
            }
        });
    }
}
