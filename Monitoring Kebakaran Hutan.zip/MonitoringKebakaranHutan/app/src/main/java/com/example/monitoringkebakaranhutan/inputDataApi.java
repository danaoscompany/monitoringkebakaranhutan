package com.example.monitoringkebakaranhutan;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import com.example.monitoringkebakaranhutan.inputDataKebakaran;
import com.google.firebase.database.ValueEventListener;

import static android.text.TextUtils.isEmpty;

public class inputDataApi extends AppCompatActivity implements View.OnClickListener {
    private final int SELECT_LOCATION = 1;
    private EditText editTextDate, editTextJam, editTextNoTelp, editTextPK, editTextLK;
    private ProgressBar progressBar;
    private Button submit;
    private String getUserid;
    private FirebaseAuth Auth;
    private FirebaseDatabase database;
    private DatabaseReference getReference;
    private double latitude = 0, longitude = 0;
    private String location = "";

    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_input_data_api );

        database = FirebaseDatabase.getInstance();
        Auth = FirebaseAuth.getInstance();
        getUserid = Auth.getCurrentUser().getUid();

        submit = (Button) findViewById( R.id.submit);
        submit.setOnClickListener(this);

        editTextJam = (EditText) findViewById( R.id.inputjam );
        editTextNoTelp = (EditText) findViewById( R.id.inputnotelp );
        editTextPK = (EditText) findViewById( R.id.inputpenyebabKebakaran );
        editTextLK = (EditText) findViewById( R.id.inputlokasiKebakaran );
        editTextLK.setOnClickListener(this);

        progressBar = (ProgressBar) findViewById( R.id.inputprogressBar );

        editTextDate = findViewById( R.id.inputtanggal );
        myCalendar = Calendar.getInstance();
        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfYear) {
                myCalendar.set( Calendar.YEAR, year );
                myCalendar.set( Calendar.MONTH, monthOfYear );
                myCalendar.set( Calendar.DAY_OF_MONTH, dayOfYear );
                updateLabel();

            }
        };
        editTextDate.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog( inputDataApi.this, date, myCalendar
                        .get( Calendar.YEAR ), myCalendar.get( Calendar.MONTH ), myCalendar.get( Calendar.DAY_OF_MONTH ) ).show();
            }
        } );
        //jam otomatis
        editTextJam.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar mCurrentTime = Calendar.getInstance();
                int hour = mCurrentTime.get( Calendar.HOUR_OF_DAY );
                int minute = mCurrentTime.get( Calendar.MINUTE );
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog( inputDataApi.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        editTextJam.setText( selectedHour + ":" + selectedMinute );

                    }
                }, hour, minute, true );
                mTimePicker.setTitle( "Select Time" );
                mTimePicker.show();
            }
        } );
    }

    private void updateLabel() {
        String myFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat( myFormat, Locale.US );
        editTextDate.setText( sdf.format( myCalendar.getTime() ) );

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.submit:
                userSubmit();
                break;
            case R.id.inputlokasiKebakaran:
                startActivityForResult(new Intent(inputDataApi.this, SelectLocationActivity.class), SELECT_LOCATION);
                break;
        }
    }

    private void userSubmit() {
        String geteditTextDate = editTextDate.getText().toString().trim();
        final String geteditTextJam = editTextJam.getText().toString().trim();
        final String geteditTextNoTelp = editTextNoTelp.getText().toString().trim();
        final String geteditTextPK = editTextPK.getText().toString().trim();
        final String geteditTextLK = editTextLK.getText().toString().trim();
        getReference = database.getReference();
        if (geteditTextDate.equals("") || geteditTextJam.equals("") || geteditTextNoTelp.equals("") || geteditTextPK.equals("")
            || geteditTextLK.equals("")) {
            Tool.show(this, R.string.text3);
            return;
        }
        if (latitude == 0 || longitude == 0) {
            Tool.show(this, R.string.text4);
            return;
        }
        Tool.write(this, "last_latitude", latitude);
        Tool.write(this, "last_longitude", longitude);
        final ProgressDialog dialog = Tool.createDialog(this, R.string.text2);
        dialog.show();
        final DatabaseReference ref = getReference.child("Users").child(getUserid).child("Data_Kebakaran").child(UUID.randomUUID().toString()).getRef();
        ref.child("date").setValue(geteditTextDate+" "+geteditTextJam+":00")
            .addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    ref.child("jam").setValue(geteditTextJam).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            ref.child("notelp").setValue(geteditTextNoTelp)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            ref.child("penyebabKebakaran").setValue(geteditTextPK)
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            ref.child("lokasiKebakaranLat").setValue(latitude)
                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                        @Override
                                                                        public void onSuccess(Void aVoid) {
                                                                            ref.child("lokasiKebakaranLng").setValue(longitude)
                                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                        @Override
                                                                                        public void onSuccess(Void aVoid) {
                                                                                            ref.child("lokasiKebakaran").setValue(location)
                                                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                                        @Override
                                                                                                        public void onSuccess(Void aVoid) {
                                                                                                            ref.child("status").setValue("terbakar").addOnSuccessListener(new OnSuccessListener<Void>() {

                                                                                                                @Override
                                                                                                                public void onSuccess(Void aVoid) {
                                                                                                                    Tool.sendMessage("Pembaruan data kebakaran hutan", "Klik untuk melihat data kebakaran hutan terbaru", "/topics/admin");
                                                                                                                    dialog.dismiss();
                                                                                                                    finish();
                                                                                                                }
                                                                                                            });
                                                                                                        }
                                                                                                    });
                                                                                        }
                                                                                    });
                                                                        }
                                                                    });
                                                        }
                                                    });
                                        }
                                    });
                        }
                    });
                }
            });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_LOCATION) {
                latitude = data.getDoubleExtra("latitude", 0);
                longitude = data.getDoubleExtra("longitude", 0);
                try {
                    Geocoder geocoder = new Geocoder(this);
                    List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
                    if (addresses != null && addresses.size() > 0) {
                        Address address = addresses.get(0);
                        if (address != null) {
                            location = address.getAddressLine(0);
                            editTextLK.setText(location);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
