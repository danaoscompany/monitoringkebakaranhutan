package com.example.monitoringkebakaranhutan;

public class User {
    public String fullname, noTelp, email;
    public User(){

    }
    public User(String fullname, String noTelp, String email){
        this.fullname = fullname;
        this.noTelp = noTelp;
        this.email = email;
    }
}
